const services = [
    { name: "Company Registration", price: 500 },
    { name: "Tax Clearance", price: 300 },
    { name: "Business Plan", price: 450 }
];

window.onload = () => {
    const serviceList = document.getElementById("service-list");
    if (serviceList) {
        services.forEach((s, i) => {
            serviceList.innerHTML += `
        <div class="col-md-4 mb-4">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">${s.name}</h5>
              <p class="card-text">R${s.price}</p>
              <button class="btn btn-primary" onclick="addToCart(${i})">Add to Cart</button>
            </div>
          </div>
        </div>
      `;
        });
    }
};

function addToCart(index) {
    alert(`Added ${services[index].name} to cart`);
}
document.addEventListener("DOMContentLoaded", () => {
    const services = [
        {
            title: "Company Registration",
            description: "Register your private company, cooperative, or NPO with us hassle-free.",
            icon: "bi-building",
        },
        {
            title: "Tax Services",
            description: "Let us help you get your Tax Clearance, PIN, and SARS compliance sorted.",
            icon: "bi-cash-stack",
        },
        {
            title: "Business Plans",
            description: "Professional business plans for funding, operations, and planning.",
            icon: "bi-journal-text",
        },
        {
            title: "CIPC Filings",
            description: "Annual returns and company updates filed on your behalf.",
            icon: "bi-file-earmark-check",
        }
    ];

    const container = document.getElementById("service-list");

    services.forEach(service => {
        container.innerHTML += `
      <div class="col-md-6 col-lg-4 mb-4">
        <div class="card h-100 shadow-sm">
          <div class="card-body">
            <h5 class="card-title">${service.title}</h5>
            <p class="card-text">${service.description}</p>
          </div>
          <div class="card-footer text-center bg-light">
            <a href="register.html" class="btn btn-primary btn-sm">Get Started</a>
          </div>
        </div>
      </div>
    `;
    });
});
emailjs.send("YOUR_SERVICE_ID", "YOUR_TEMPLATE_ID", {
    to_name: name,
    to_email: email,
    message: `Thank you for registering for ${service}. We have received your submission.`,
})
    .then(() => console.log("Email sent"))
    .catch((error) => console.error("Email send failed:", error));
