// firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

// Your Firebase project config (replace with your own config)
const firebaseConfig = {
    apiKey: "oX65qWddS5h5FB5ar",
    authDomain: "secoka57@gmail.com",
    projectId: "secoka57",
    storageBucket: "secoka57.appspot.com",
    messagingSenderId: "secoka57@gmail.com",
    appId: "1:secoka57:web:secoka57"
};

// Initialize Firebase app and Firestore
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };
